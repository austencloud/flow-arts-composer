// Public API for @austencloud/drawer
export { default as Drawer } from './Drawer.svelte';
export { configureDrawerStack, hasOpenDrawers, getStackDepth } from './drawer/DrawerStack.js';
export { DEFAULT_INERT_EXCLUSIONS } from './drawer/FocusTrap.js';
export { SwipeToDismiss } from './drawer/SwipeToDismiss.js';
export type {
	DrawerPlacement,
	CloseReason,
	SnapPointValue,
	DrawerProps,
	FocusTrapOptions,
	SwipeToDismissOptions,
	DrawerEffectsOptions
} from './types.js';
