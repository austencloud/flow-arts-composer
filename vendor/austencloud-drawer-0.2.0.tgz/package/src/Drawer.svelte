<!--
  Drawer.svelte - Production drawer with pure CSS animations

  Features:
  - Slides from right, left, top, or bottom based on placement
  - Placement-aware swipe gestures (horizontal for side drawers, vertical for top/bottom)
  - Smooth CSS transitions with @starting-style entry animations
  - Native <dialog> element for proper semantics and accessibility
  - Focus trapping (WAI-ARIA compliant)
  - Inert attribute on background content
  - Snap points for multi-height drawers
  - Drawer stacking for nested drawers
  - Spring animation option
  - Background scale effect
  - Reduced motion support
  - Themeable via --drawer-* CSS custom properties
-->
<script lang="ts">
	import './drawer/Drawer.css';
	import { onMount, onDestroy, untrack, type Snippet } from 'svelte';
	import { SwipeToDismiss } from './drawer/SwipeToDismiss.js';
	import { FocusTrap, DEFAULT_INERT_EXCLUSIONS } from './drawer/FocusTrap.js';
	import { SnapPoints } from './drawer/SnapPoints.js';
	import { DrawerEffects } from './drawer/DrawerEffects.js';
	import {
		generateDrawerId,
		registerDrawer,
		unregisterDrawer,
		isTopDrawer,
		claimEscape
	} from './drawer/DrawerStack.js';
	import type { DrawerPlacement, CloseReason, SnapPointValue } from './types.js';

	let {
		isOpen = $bindable(false),
		closeOnBackdrop = true,
		closeOnEscape = true,
		dismissible = true,
		modal = true,
		dragHandleOnly = false,
		labelledBy,
		ariaLabel,
		title,
		describedBy,
		role = 'dialog',
		showHandle = true,
		class: drawerClass = '',
		backdropClass = '',
		placement = 'bottom',
		responsivePlacement = false,
		mobileBreakpoint = '(max-width: 768px)',
		// Focus trap options
		trapFocus = true,
		initialFocusElement = null,
		focusContainerOnOpen = false,
		returnFocusOnClose = true,
		setInertOnSiblings = true,
		inertExclusions = [],
		// Snap points options
		snapPoints = null,
		activeSnapPoint = $bindable<number | null>(null),
		closeOnSnapToZero = true,
		resizeWithSnapPoints = false,
		// Animation options
		springAnimation = false,
		scaleBackground = false,
		preventScroll = true,
		keepMounted = false,
		holdOpen = false,
		// Focus behavior
		autoFocus = true,
		keyboardShortcutsPassthrough = false,
		onclose,
		onBeforeClose,
		onOpenChange,
		onbackdropclick,
		onDragChange,
		onSnapPointChange,
		children
	}: {
		isOpen?: boolean;
		closeOnBackdrop?: boolean;
		closeOnEscape?: boolean;
		dismissible?: boolean;
		modal?: boolean;
		dragHandleOnly?: boolean;
		labelledBy?: string;
		ariaLabel?: string;
		title?: string;
		describedBy?: string;
		role?: 'dialog' | 'menu' | 'listbox' | 'alertdialog';
		showHandle?: boolean;
		class?: string;
		backdropClass?: string;
		placement?: DrawerPlacement;
		/** When true, uses bottom placement on mobile regardless of specified placement */
		responsivePlacement?: boolean;
		/** matchMedia query for mobile detection (default: '(max-width: 768px)') */
		mobileBreakpoint?: string;
		trapFocus?: boolean;
		initialFocusElement?: HTMLElement | null;
		focusContainerOnOpen?: boolean;
		returnFocusOnClose?: boolean;
		setInertOnSiblings?: boolean;
		/** Additional CSS class names to exclude from inert (merged with ['drawer-overlay']) */
		inertExclusions?: string[];
		snapPoints?: SnapPointValue[] | null;
		activeSnapPoint?: number | null;
		closeOnSnapToZero?: boolean;
		resizeWithSnapPoints?: boolean;
		springAnimation?: boolean;
		scaleBackground?: boolean;
		preventScroll?: boolean;
		keepMounted?: boolean;
		holdOpen?: boolean;
		autoFocus?: boolean;
		keyboardShortcutsPassthrough?: boolean;
		onclose?: (event: CustomEvent<{ reason: CloseReason }>) => void;
		onBeforeClose?: (reason: CloseReason) => boolean | void;
		onOpenChange?: (open: boolean) => void;
		onbackdropclick?: (event: MouseEvent) => boolean;
		onDragChange?: (offset: number, progress: number, isDragging: boolean) => void;
		onSnapPointChange?: (index: number, valuePx: number) => void;
		children?: Snippet;
	} = $props();

	// Merge consumer exclusions with the package default
	const mergedExclusions = $derived([...DEFAULT_INERT_EXCLUSIONS, ...inertExclusions]);

	// Simple mobile detection (replaces TKA's responsiveLayoutManager)
	let isMobile = $state(false);
	let mounted = $state(false);
	let wasOpen = $state(false);
	let pendingCloseReason: CloseReason = 'programmatic';
	let shouldRender = $state(false);
	let isAnimatedOpen = $state(false);
	let isAnimating = $state(false);
	let closeTimeoutId: ReturnType<typeof setTimeout> | null = null;
	let animatingTimeoutId: ReturnType<typeof setTimeout> | null = null;
	let holdCapId: ReturnType<typeof setTimeout> | null = null;
	let heldOpen: (() => void) | null = null;
	let isHoldingOpen = $state(false);
	let transitionGeneration = 0;
	const HOLD_OPEN_CAP_MS = 1200;

	function clearHeldOpen() {
		heldOpen = null;
		isHoldingOpen = false;
		if (holdCapId !== null) clearTimeout(holdCapId);
		holdCapId = null;
	}

	function releaseHeldOpen() {
		const run = heldOpen;
		if (!run) return;
		clearHeldOpen();
		requestAnimationFrame(run);
	}

	$effect(() => {
		if (!holdOpen) untrack(releaseHeldOpen);
	});

	function motionDurationMs(): number {
		if (prefersReducedMotion()) return 0;
		const style = getComputedStyle(drawerElement ?? document.documentElement);
		const raw = style.getPropertyValue('--drawer-transition-duration').trim()
			|| style.getPropertyValue('--duration-dramatic').trim();
		const value = Number.parseFloat(raw);
		return Number.isFinite(value) ? value * (raw.endsWith('s') && !raw.endsWith('ms') ? 1000 : 1) : 350;
	}

	const prefersReducedMotion = () =>
		typeof window !== 'undefined' &&
		window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;

	// Drawer stack management
	const drawerId = generateDrawerId();
	let stackZIndex = $state(200);

	// Reactive state for drag visuals
	let isDragging = $state(false);
	let dragOffsetX = $state(0);
	let dragOffsetY = $state(0);

	let handlersInitialized = $state(false);

	// Compute effective placement: on mobile, bottom sheet is more natural
	const effectivePlacement = $derived.by(() => {
		if (responsivePlacement && isMobile) {
			return 'bottom';
		}
		return placement;
	});
	const effectiveShowHandle = $derived(showHandle);
	const heightSnaps = $derived(resizeWithSnapPoints && effectivePlacement === 'bottom' && !!snapPoints?.length);
	const resolvedAriaLabel = $derived(labelledBy ? undefined : (ariaLabel ?? title));

	function handleInternalDragChange(offset: number, progress: number, dragging: boolean) {
		isDragging = dragging;
		if (effectivePlacement === 'right' || effectivePlacement === 'left') {
			dragOffsetX = offset;
			dragOffsetY = 0;
		} else {
			dragOffsetX = 0;
			dragOffsetY = offset;
		}
		onDragChange?.(offset, progress, dragging);
	}

	function handleDragEnd(offset: number, velocity: number, duration: number): boolean {
		if (!snapPointsInstance || !snapPoints || snapPoints.length === 0) {
			return false;
		}

		const targetIndex = snapPointsInstance.calculateTargetSnapPoint(offset, velocity, duration);
		if (targetIndex === 0 && closeOnSnapToZero) {
			if (requestClose('snap')) {
				snapPointsInstance.setSnapPoint(0);
				snapPointOffset = snapPointsInstance.getTransformOffset();
			}
			return true;
		}
		snapPointsInstance.setSnapPoint(targetIndex);
		snapPointOffset = snapPointsInstance.getTransformOffset();

		return true;
	}

	function toggleHeightSnap() {
		if (!snapPointsInstance || !heightSnaps) return;
		const last = snapPointsInstance.getCount() - 1;
		snapPointsInstance.setSnapPoint(currentSnapIndex === last ? Math.max(1, last - 1) : last);
		snapPointOffset = snapPointsInstance.getTransformOffset();
	}

	let drawerElement = $state<HTMLDialogElement | null>(null);
	let swipeToDismiss = $state<SwipeToDismiss | null>(null);
	let focusTrap: FocusTrap | null = null;
	let snapPointsInstance: SnapPoints | null = null;
	let snapPointOffset = $state(0);
	let currentSnapIndex = $state<number | null>(null);
	let drawerEffects: DrawerEffects | null = null;
	const snapHeight = $derived(
		heightSnaps && isAnimatedOpen && snapPointsInstance
			? `${Math.max(0, window.innerHeight - snapPointOffset - (isDragging ? dragOffsetY : 0))}px`
			: undefined
	);

	function initializeHandlers() {
		if (handlersInitialized) return;
		handlersInitialized = true;

		swipeToDismiss = new SwipeToDismiss({
			placement: effectivePlacement,
			dismissible,
			dragHandleOnly,
			allowReverseDrag: heightSnaps && (snapPoints?.length ?? 0) > 1,
			drawerId,
			onDismiss: () => {
				requestClose('swipe');
			},
			onDragChange: handleInternalDragChange,
			onDragEnd: handleDragEnd
		});

		focusTrap = new FocusTrap({
			initialFocus: initialFocusElement ?? null,
			focusContainerOnInitial: focusContainerOnOpen,
			isTopLayer: () => isTopDrawer(drawerId),
			returnFocusOnDeactivate: returnFocusOnClose,
			setInertOnSiblings: setInertOnSiblings,
			inertExclusions: mergedExclusions
		});

		drawerEffects = new DrawerEffects({
			scaleBackground,
			preventScroll,
			isAnimatedOpen: false
		});
	}

	// Update SwipeToDismiss when placement changes
	$effect(() => {
		if (!handlersInitialized) return;
		swipeToDismiss = new SwipeToDismiss({
			placement: effectivePlacement,
			dismissible,
			dragHandleOnly,
			allowReverseDrag: heightSnaps && (snapPoints?.length ?? 0) > 1,
			drawerId,
			onDismiss: () => {
				requestClose('swipe');
			},
			onDragChange: handleInternalDragChange,
			onDragEnd: handleDragEnd
		});
	});

	// Initialize snap points when provided
	$effect(() => {
		if (!handlersInitialized) return;
		if (snapPoints && snapPoints.length > 0) {
			snapPointsInstance = new SnapPoints({
				placement: effectivePlacement,
				snapPoints,
				defaultSnapPoint: untrack(() => activeSnapPoint) ?? snapPoints.length - 1,
				onSnapPointChange: (index, valuePx) => {
					currentSnapIndex = index;
					activeSnapPoint = index;
					onSnapPointChange?.(index, valuePx);
				}
			});
			currentSnapIndex = snapPointsInstance.getCurrentIndex();
		} else {
			snapPointsInstance = null;
			snapPointOffset = 0;
			currentSnapIndex = null;
		}
	});

	// Initialize snap handler dimensions
	$effect(() => {
		if (drawerElement && snapPointsInstance && isAnimatedOpen) {
			const viewportWidth = window.innerWidth;
			const viewportHeight = window.innerHeight;
			snapPointsInstance.initialize(viewportWidth, viewportHeight);
			snapPointOffset = snapPointsInstance.getTransformOffset();
		}
	});

	onMount(() => {
		mounted = true;
		if (keepMounted) shouldRender = true;

		// Simple mobile detection using configurable breakpoint
		const mql = window.matchMedia(mobileBreakpoint);
		isMobile = mql.matches;

		const handleChange = (e: MediaQueryListEvent) => {
			isMobile = e.matches;
		};
		mql.addEventListener('change', handleChange);

		return () => {
			mql.removeEventListener('change', handleChange);
		};
	});

	// Track open state changes
	$effect(() => {
		const previouslyOpen = untrack(() => wasOpen);
		const nextOpen = isOpen;

		if (nextOpen !== previouslyOpen) {
			const generation = ++transitionGeneration;
			onOpenChange?.(nextOpen);

			if (nextOpen) {
				const returnFocusTarget = document.activeElement as HTMLElement | null;
				if (closeTimeoutId !== null) {
					clearTimeout(closeTimeoutId);
					closeTimeoutId = null;
				}
				if (animatingTimeoutId !== null) {
					clearTimeout(animatingTimeoutId);
					animatingTimeoutId = null;
				}
				clearHeldOpen();

				isAnimating = true;
				initializeHandlers();

				stackZIndex = registerDrawer(drawerId, () => { requestClose('swipe'); }, () => isOpen);
				shouldRender = true;
				swipeToDismiss?.reset();

				const completeOpen = () => {
					if (generation !== transitionGeneration || !untrack(() => isOpen)) return;
					drawerElement?.show();
					isAnimatedOpen = true;
					if (trapFocus && drawerElement && focusTrap) {
						focusTrap.activate(drawerElement, returnFocusTarget);
					} else if (autoFocus && drawerElement) {
						drawerElement.focus();
					}

					animatingTimeoutId = setTimeout(() => {
						isAnimating = false;
					}, motionDurationMs() + 50);
				};

				if (prefersReducedMotion()) {
					isAnimatedOpen = true;
					isAnimating = false;
					requestAnimationFrame(completeOpen);
				} else {
					isAnimatedOpen = false;
					if (untrack(() => holdOpen)) {
						heldOpen = completeOpen;
						isHoldingOpen = true;
						holdCapId = setTimeout(releaseHeldOpen, HOLD_OPEN_CAP_MS);
					} else {
						requestAnimationFrame(() => { requestAnimationFrame(completeOpen); });
					}
				}
			}

			if (previouslyOpen && !nextOpen) {
				clearHeldOpen();
				emitClose(pendingCloseReason);
				pendingCloseReason = 'programmatic';
				isAnimatedOpen = false;
				swipeToDismiss?.reset();
				focusTrap?.deactivate();
				unregisterDrawer(drawerId);

				const completeClose = () => {
					if (generation !== transitionGeneration || untrack(() => isOpen)) return;
					drawerElement?.close();
					if (!keepMounted) shouldRender = false;
				};

				if (prefersReducedMotion()) {
					completeClose();
				} else {
					closeTimeoutId = setTimeout(completeClose, motionDurationMs() + 50);
				}
			}

			untrack(() => {
				wasOpen = nextOpen;
			});
		}
	});

	function emitClose(reason: CloseReason) {
		if (onclose) {
			onclose(new CustomEvent('close', { detail: { reason } }));
		}
	}

	/** Requests a close; false means the drawer stayed open. Direct bound prop changes are uncancellable. */
	export function requestClose(reason: CloseReason = 'programmatic'): boolean {
		if (!isOpen || onBeforeClose?.(reason) === false) return false;
		pendingCloseReason = reason;
		isOpen = false;
		return true;
	}

	function handleBackdropClick(event: MouseEvent) {
		if (!isOpen || !isTopDrawer(drawerId)) return;
		if (onbackdropclick) {
			const shouldClose = onbackdropclick(event);
			if (shouldClose) {
				requestClose('backdrop');
			}
			return;
		}

		if (closeOnBackdrop) {
			requestClose('backdrop');
		}
	}

	function handleKeydown(event: KeyboardEvent) {
		if (event.key === 'Escape' && closeOnEscape && isOpen && claimEscape(event, drawerId)) {
			requestClose('escape');
		}
	}

	function handleDialogCancel(event: Event) {
		event.preventDefault();
		if (closeOnEscape && isTopDrawer(drawerId)) requestClose('escape');
	}

	const dataState = $derived(isAnimatedOpen ? 'open' : 'closed');
	const overlayState = $derived(isAnimatedOpen || isHoldingOpen ? 'open' : 'closed');

	const overlayClasses = $derived(`drawer-overlay ${backdropClass}`.trim());

	const contentClasses = $derived(`drawer-content ${drawerClass}`.trim());

	const computedTransform = $derived.by(() => {
		if (heightSnaps) return '';
		if (isDragging && (dragOffsetY !== 0 || dragOffsetX !== 0)) {
			const isHorizontal = effectivePlacement === 'left' || effectivePlacement === 'right';
			if (isHorizontal) {
				return `translateX(${dragOffsetX + snapPointOffset}px)`;
			} else {
				return `translateY(${dragOffsetY + snapPointOffset}px)`;
			}
		}

		if (snapPointOffset !== 0 && isAnimatedOpen) {
			const isHorizontal = effectivePlacement === 'left' || effectivePlacement === 'right';
			if (isHorizontal) {
				return `translateX(${snapPointOffset}px)`;
			} else {
				return `translateY(${snapPointOffset}px)`;
			}
		}

		return '';
	});

	// Update focus trap options when props change
	$effect(() => {
		if (!focusTrap) return;
		focusTrap.updateOptions({
			initialFocus: initialFocusElement,
			focusContainerOnInitial: focusContainerOnOpen,
			returnFocusOnDeactivate: returnFocusOnClose,
			setInertOnSiblings: setInertOnSiblings,
			inertExclusions: mergedExclusions
		});
	});

	// Attach/detach swipe handler
	$effect(() => {
		if (drawerElement && swipeToDismiss) {
			swipeToDismiss.attach(drawerElement);
		}
		return () => {
			swipeToDismiss?.detach();
		};
	});

	// Disable swipe during animation
	$effect(() => {
		swipeToDismiss?.setDisabled(isAnimating);
	});

	// Update drawer effects
	$effect(() => {
		if (!drawerEffects) return;
		drawerEffects.update({
			scaleBackground,
			preventScroll,
			isAnimatedOpen
		});
	});

	onDestroy(() => {
		swipeToDismiss?.detach();
		focusTrap?.deactivate();
		drawerEffects?.cleanup();
		unregisterDrawer(drawerId);
		if (closeTimeoutId !== null) clearTimeout(closeTimeoutId);
		if (animatingTimeoutId !== null) clearTimeout(animatingTimeoutId);
		clearHeldOpen();
	});
</script>

<svelte:window onkeydown={handleKeydown} />

{#if mounted && shouldRender}
	<!-- Backdrop -->
	<div
		class={overlayClasses}
		data-state={overlayState}
		onclick={handleBackdropClick}
		aria-hidden="true"
		style:z-index={stackZIndex - 1}
	></div>

	<!-- Drawer content -->
	<dialog
		bind:this={drawerElement}
		class={contentClasses}
		class:dragging={isDragging}
		class:has-snap-points={snapPoints && snapPoints.length > 0}
		class:height-snap-points={heightSnaps}
		class:spring-animation={springAnimation}
		data-placement={effectivePlacement}
		data-state={dataState}
		data-snap-index={currentSnapIndex}
		data-drawer-id={drawerId}
		data-keyboard-shortcuts-passthrough={keyboardShortcutsPassthrough ? '' : undefined}
		tabindex="-1"
		aria-modal={modal ? 'true' : undefined}
		aria-labelledby={labelledBy}
		aria-label={resolvedAriaLabel}
		aria-describedby={describedBy}
		{role}
		oncancel={handleDialogCancel}
		oncontextmenu={(e) => {
			e.preventDefault();
			return false;
		}}
		style:z-index={stackZIndex}
		style:transform={computedTransform || undefined}
		style:height={snapHeight}
		style:transition={isDragging ? 'none' : ''}
	>
		{#if effectiveShowHandle}
			{#if heightSnaps}
				<button type="button" class="drawer-handle" aria-label={currentSnapIndex === (snapPoints?.length ?? 0) - 1 ? 'Collapse drawer' : 'Expand drawer'} onclick={toggleHeightSnap}></button>
			{:else}
				<div class="drawer-handle" aria-hidden="true"></div>
			{/if}
		{/if}
		<div class="drawer-inner">
			{@render children?.()}
		</div>
	</dialog>
{/if}
