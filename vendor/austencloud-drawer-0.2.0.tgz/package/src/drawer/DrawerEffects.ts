/**
 * DrawerEffects - Manages visual side effects when drawers open
 *
 * Handles:
 * - Background scale effect (iOS-like depth)
 * - Scroll lock (prevents body scroll while drawer is open)
 */

import type { DrawerEffectsOptions } from '../types.js';

const scrollLockOwners = new Set<DrawerEffects>();
let originalBodyOverflow: string | null = null;
const scaleOwners = new Set<DrawerEffects>();

export class DrawerEffects {
	private options: DrawerEffectsOptions;

	constructor(options: DrawerEffectsOptions) {
		this.options = options;
	}

	apply() {
		if (this.options.scaleBackground) {
			this.applyScaleBackground();
		}
		if (this.options.preventScroll) {
			this.applyScrollLock();
		}
	}

	cleanup() {
		if (this.options.scaleBackground) {
			this.cleanupScaleBackground();
		}
		if (this.options.preventScroll) {
			this.cleanupScrollLock();
		}
	}

	update(options: Partial<DrawerEffectsOptions>) {
		const changed =
			options.isAnimatedOpen !== this.options.isAnimatedOpen ||
			options.preventScroll !== this.options.preventScroll ||
			options.scaleBackground !== this.options.scaleBackground;

		if (changed) {
			this.cleanup();
			this.options = { ...this.options, ...options };
			this.apply();
		}
	}

	private applyScaleBackground() {
		if (!this.options.isAnimatedOpen || scaleOwners.has(this)) return;
		scaleOwners.add(this);
		document.body.style.setProperty('--drawer-bg-scale', '0.96');
		document.body.style.setProperty('--drawer-bg-border-radius', '8px');
		document.body.classList.add('drawer-scale-bg-active');
	}

	private cleanupScaleBackground() {
		if (!scaleOwners.delete(this) || scaleOwners.size > 0) return;
		document.body.style.removeProperty('--drawer-bg-scale');
		document.body.style.removeProperty('--drawer-bg-border-radius');
		document.body.classList.remove('drawer-scale-bg-active');
	}

	private applyScrollLock() {
		if (!this.options.isAnimatedOpen || scrollLockOwners.has(this)) return;
		if (scrollLockOwners.size === 0) originalBodyOverflow = document.body.style.overflow;
		scrollLockOwners.add(this);
		document.body.style.overflow = 'hidden';
	}

	private cleanupScrollLock() {
		if (!scrollLockOwners.delete(this) || scrollLockOwners.size > 0) return;
		document.body.style.overflow = originalBodyOverflow ?? '';
		originalBodyOverflow = null;
	}
}
