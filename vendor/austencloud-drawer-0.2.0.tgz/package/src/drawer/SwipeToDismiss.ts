/**
 * SwipeToDismiss - Manages swipe-to-dismiss gesture interactions
 *
 * Handles touch and mouse events for drawer dismissal with threshold-based detection.
 * Placement-aware: horizontal gestures for right/left drawers, vertical for top/bottom.
 *
 * Each gesture is decided once. It starts pending and moves nothing. When the
 * pointer has travelled past the recognition slop the handler either claims it
 * (a drag along the drawer's own axis, toward dismiss, with any scroll
 * container at its edge) or releases it. A released gesture belongs to the page
 * for the rest of its life: native scrolling, sideways swipes and taps go on
 * untouched, and no later movement can turn it into a drag.
 *
 * Opt-outs: a gesture that starts inside `[data-swipe-block]`, on a range input
 * or on an ARIA slider is never tracked, so content that owns its own gestures
 * (pickers, scrubbers, 3D canvases) keeps them.
 */

import { isTopDrawer, dismissTopDrawer } from './DrawerStack.js';
import type { SwipeToDismissOptions } from '../types.js';

const GESTURE = {
	/** A slow, deliberate pull this far closes the drawer. */
	DISTANCE_SLOW: 100,
	/** A quick flick this far closes the drawer. */
	DISTANCE_FAST: 50,
	/** A pull shorter than this (ms) counts as a quick flick. */
	FAST_SWIPE_MAX_DURATION: 500,
	/**
	 * Starting with a list already scrolled to its edge, the pull must be this
	 * long to close, however fast, so a scroll flick at the top of a list
	 * springs back instead of closing.
	 */
	DISTANCE_BOUNDARY: 140,
	/** A pull that starts at a list's edge moves the drawer at this fraction of the finger. */
	RUBBER_BAND_FACTOR: 0.5,
	/**
	 * A finger can wander this far (px, straight line) before anything moves,
	 * so taps and wobbles never shift the drawer.
	 */
	RECOGNITION_SLOP: 10,
	/**
	 * A press that starts on a button, link or other control can wander this far
	 * before it reads as a drag, so a sloppy tap never twitches the drawer.
	 */
	INTERACTIVE_SLOP: 24,
	/** On the grab handle the drawer picks up almost at once, in any direction toward closing. */
	HANDLE_SLOP: 4,
	/** A mouse press can wander this far before it reads as a drag rather than a click. */
	MOUSE_SLOP: 5,
	/**
	 * Movement along the drawer's axis must be at least this many times the
	 * movement across it (about 34 degrees either side of the axis), so a
	 * sideways swipe that drifts never grabs the drawer.
	 */
	AXIS_DOMINANCE: 1.5
} as const;

/**
 * A menu or popover floating over a sheet never moves the sheet, whatever the
 * finger or mouse does inside it. A floating layer is any element between the
 * press and the sheet's own root (the root excluded) that is a menu, listbox
 * or popover, or that is fixed in place on screen the way floating menus and
 * popovers are drawn.
 */
const FLOATING_LAYER = '[role="menu"], [role="listbox"], [popover], [data-floating-layer]';

function startsInFloatingLayer(target: Element, root: HTMLElement | null): boolean {
	if (!root || !root.contains(target)) return false;
	const view = root.ownerDocument.defaultView;
	for (let node: Element | null = target; node && node !== root; node = node.parentElement) {
		if (node.matches(FLOATING_LAYER)) return true;
		if (view && view.getComputedStyle(node).position === 'fixed') return true;
	}
	return false;
}

export { type SwipeToDismissOptions };

type GestureState = 'idle' | 'pending' | 'claimed' | 'released';

export class SwipeToDismiss {
	private element: HTMLElement | null = null;
	private state: GestureState = 'idle';
	private pointer: 'touch' | 'mouse' = 'touch';
	private startY = 0;
	private startX = 0;
	// Where the gesture was claimed; the drawer's offset is measured from here
	// so it starts at 0 instead of jumping by the slop.
	private claimY = 0;
	private claimX = 0;
	private currentY = 0;
	private currentX = 0;
	private startTime = 0;
	private hasMoved = false;
	private startedOnInteractive = false;
	private startedOnHandle = false;
	private justDragged = false;
	private cleanupFn: (() => void) | null = null;

	private scrollableContainer: HTMLElement | null = null;
	// True when this gesture began with a scroll container already at its
	// dismiss edge: rubber band and the higher, distance-only dismiss threshold.
	private startedAtScrollBoundary = false;

	// Delegation flag: when true, this drawer is not the top drawer,
	// so swipe gestures should dismiss the top drawer instead
	private delegatingToTopDrawer = false;

	// Disabled flag: when true, all gesture handling is blocked
	// Used during open/close animations to prevent conflicts
	private disabled = false;

	constructor(private options: SwipeToDismissOptions) {}

	/**
	 * Temporarily disable gesture handling (e.g., during animations)
	 */
	setDisabled(disabled: boolean) {
		this.disabled = disabled;
		if (!disabled) return;
		if (this.state === 'claimed') {
			this.options.onDragChange?.(0, 1, false);
		}
		if (this.state === 'claimed' || this.state === 'pending') {
			this.state = 'released';
		}
	}

	/**
	 * Find the nearest scrollable ancestor from the touch target
	 */
	private findScrollableAncestor(target: HTMLElement): HTMLElement | null {
		let current: HTMLElement | null = target;
		while (current && current !== this.element) {
			// Form elements have overflow:auto by default but shouldn't block dismiss
			const tagName = current.tagName.toLowerCase();
			if (tagName === 'textarea' || tagName === 'input' || tagName === 'select') {
				current = current.parentElement;
				continue;
			}

			const style = window.getComputedStyle(current);
			const overflowY = style.overflowY;
			const overflowX = style.overflowX;

			const isScrollableY =
				(overflowY === 'auto' || overflowY === 'scroll') &&
				current.scrollHeight > current.clientHeight;
			const isScrollableX =
				(overflowX === 'auto' || overflowX === 'scroll') &&
				current.scrollWidth > current.clientWidth;

			if (isScrollableY || isScrollableX) {
				return current;
			}
			current = current.parentElement;
		}
		return null;
	}

	/**
	 * Check if scroll is at the boundary where dismiss gesture would occur
	 */
	private isScrollAtDismissBoundary(container: HTMLElement): boolean {
		const { placement } = this.options;

		if (placement === 'bottom') {
			return container.scrollTop <= 1;
		} else if (placement === 'top') {
			const maxScroll = container.scrollHeight - container.clientHeight;
			return container.scrollTop >= maxScroll - 1;
		} else if (placement === 'right') {
			return container.scrollLeft <= 1;
		} else if (placement === 'left') {
			const maxScroll = container.scrollWidth - container.clientWidth;
			return container.scrollLeft >= maxScroll - 1;
		}
		return true;
	}

	/**
	 * Attach event listeners to the target element
	 */
	attach(element: HTMLElement) {
		this.detach();
		this.element = element;

		const handleStart = (e: TouchEvent | MouseEvent) => this.handleTouchStart(e);
		const handleMove = (e: TouchEvent | MouseEvent) => this.handleTouchMove(e);
		const handleEnd = (e: TouchEvent | MouseEvent) => this.handleTouchEnd(e);
		const handleClick = (e: MouseEvent) => this.handleClick(e);

		element.addEventListener('touchstart', handleStart, { passive: false });
		element.addEventListener('touchmove', handleMove, { passive: false });
		element.addEventListener('touchend', handleEnd, { passive: false });

		element.addEventListener('mousedown', handleStart, { passive: false });
		element.addEventListener('mousemove', handleMove, { passive: false });
		element.addEventListener('mouseup', handleEnd, { passive: false });
		element.addEventListener('mouseleave', handleEnd, { passive: false });

		// Capture phase to intercept before button handlers
		element.addEventListener('click', handleClick, { capture: true });

		this.cleanupFn = () => {
			element.removeEventListener('touchstart', handleStart);
			element.removeEventListener('touchmove', handleMove);
			element.removeEventListener('touchend', handleEnd);
			element.removeEventListener('mousedown', handleStart);
			element.removeEventListener('mousemove', handleMove);
			element.removeEventListener('mouseup', handleEnd);
			element.removeEventListener('mouseleave', handleEnd);
			element.removeEventListener('click', handleClick, true);
		};
	}

	/**
	 * Remove event listeners and clean up
	 */
	detach() {
		if (this.cleanupFn) {
			this.cleanupFn();
			this.cleanupFn = null;
		}
		this.element = null;
	}

	/**
	 * Update options (e.g., when props change)
	 */
	updateOptions(options: Partial<SwipeToDismissOptions>) {
		this.options = { ...this.options, ...options };
	}

	/**
	 * True only while a claimed drag is moving the drawer.
	 */
	getIsDragging(): boolean {
		return this.state === 'claimed';
	}

	/**
	 * Get current drag offset for Y axis
	 */
	getDragOffsetY(): number {
		if (this.state !== 'claimed') return 0;
		return this.getDragOffsetYInternal(this.currentY - this.claimY);
	}

	/**
	 * Get current drag offset for X axis
	 */
	getDragOffsetX(): number {
		if (this.state !== 'claimed') return 0;
		return this.getDragOffsetXInternal(this.currentX - this.claimX);
	}

	/**
	 * Reset drag state
	 */
	reset() {
		this.state = 'idle';
		this.hasMoved = false;
		this.startedOnInteractive = false;
		this.startedOnHandle = false;
		// justDragged is intentionally NOT cleared here; it has its own 100ms
		// timeout. Clearing it here races: the drawer close effect calls reset()
		// before the click event fires, letting the click through to buttons.
		this.delegatingToTopDrawer = false;
		this.startY = 0;
		this.startX = 0;
		this.claimY = 0;
		this.claimX = 0;
		this.currentY = 0;
		this.currentX = 0;
		this.scrollableContainer = null;
		this.startedAtScrollBoundary = false;
	}

	/** Apply overscroll resistance to edge-origin pulls (native rubber-band). */
	private damp(delta: number): number {
		return this.startedAtScrollBoundary ? delta * GESTURE.RUBBER_BAND_FACTOR : delta;
	}

	private isHorizontal(): boolean {
		return this.options.placement === 'right' || this.options.placement === 'left';
	}

	/** A second finger is a pinch, never a drag: let a pending gesture go, spring a claimed one back. */
	private letGoForSecondFinger() {
		if (this.state === 'claimed') {
			this.swallowClickIfDraggedFromControl();
			this.options.onDragChange?.(0, 1, false);
		}
		if (this.state === 'claimed' || this.state === 'pending') {
			this.state = 'released';
		}
	}

	private swallowClickIfDraggedFromControl(event?: Event) {
		if (!this.startedOnInteractive || !this.hasMoved) return;
		event?.preventDefault();
		event?.stopPropagation();
		this.justDragged = true;
		setTimeout(() => {
			this.justDragged = false;
		}, 100);
	}

	private handleTouchStart(event: TouchEvent | MouseEvent) {
		if ('touches' in event && event.touches.length > 1) {
			this.letGoForSecondFinger();
			return;
		}
		if (this.disabled) return;
		if (!this.options.dismissible) return;

		// Ignore right-click (context menu). `"touches" in event` rather than
		// `instanceof TouchEvent`: desktop Safari has no TouchEvent global, and
		// referencing it throws on every mouse interaction.
		if (!('touches' in event) && event.button !== 0) return;

		// Only the top drawer tracks gestures, so a parent and child drawer never
		// both process the same swipe.
		if (this.options.drawerId && !isTopDrawer(this.options.drawerId)) return;
		this.delegatingToTopDrawer = false;

		const target = event.target as HTMLElement;
		if (this.options.dragHandleOnly && !target.closest('.drawer-handle')) return;

		// Dragging a slider thumb must never read as a swipe-to-dismiss.
		if (target.closest('input[type="range"]')) return;
		// Nor scrubbing any ARIA slider (progress bars, scrubbers).
		if (target.closest('[role="slider"]')) return;

		// A blocked descendant owns the gesture even when this handler lives under
		// another blocked region. `ignoreSwipeBlock` only exempts markers above the
		// attached element, such as a dock root above its own tray.
		const blockedRegion = target.closest('[data-swipe-block]');
		if (
			blockedRegion &&
			(!this.options.ignoreSwipeBlock || this.element?.contains(blockedRegion))
		) {
			return;
		}

		// A floating layer inside the drawer owns its gestures. It is not a
		// marker, so `ignoreSwipeBlock` does not switch it off.
		if (startsInFloatingLayer(target, this.element)) return;

		// Canvases that own pointer gestures (e.g. 3D orbit controls) opt out by
		// marking an ancestor with `data-swipe-block`, even above an
		// `ignoreSwipeBlock` handler. Unmarked canvases pass through to dismiss.
		const canvasEl =
			target.tagName === 'CANVAS'
				? (target as HTMLCanvasElement)
				: (target.closest('canvas') as HTMLCanvasElement | null);
		if (canvasEl?.closest('[data-swipe-block]')) return;

		this.startedOnInteractive = !!(
			target.closest('button') ||
			target.closest('a') ||
			target.closest('input') ||
			target.closest('select') ||
			target.closest('textarea') ||
			target.closest('[role="button"]')
		);
		this.startedOnHandle = !!target.closest('.drawer-handle');

		this.scrollableContainer = this.findScrollableAncestor(target);
		// Rubber-band only when there IS scrollable content and we start at its
		// edge. A non-scrollable panel keeps the easy pull-to-dismiss.
		this.startedAtScrollBoundary =
			!!this.scrollableContainer && this.isScrollAtDismissBoundary(this.scrollableContainer);

		if ('touches' in event) {
			const touch = event.touches[0]!;
			this.startY = touch.clientY;
			this.startX = touch.clientX;
			this.pointer = 'touch';
		} else {
			this.startY = event.clientY;
			this.startX = event.clientX;
			this.pointer = 'mouse';
		}
		this.currentY = this.startY;
		this.currentX = this.startX;
		this.claimY = this.startY;
		this.claimX = this.startX;
		this.startTime = Date.now();
		this.hasMoved = false;
		this.state = 'pending';
	}

	private handleTouchMove(event: TouchEvent | MouseEvent) {
		if (!this.options.dismissible) return;
		if ('touches' in event && event.touches.length > 1) {
			this.letGoForSecondFinger();
			return;
		}
		if (this.state !== 'pending' && this.state !== 'claimed') return;

		if ('touches' in event) {
			const touch = event.touches[0]!;
			this.currentY = touch.clientY;
			this.currentX = touch.clientX;
		} else {
			this.currentY = event.clientY;
			this.currentX = event.clientX;
		}

		if (this.state === 'pending') {
			this.decide(event);
			return;
		}

		if (this.delegatingToTopDrawer) return;

		// The drawer owns a claimed gesture for its whole life: no native panning.
		event.preventDefault();
		this.reportDragProgress();
	}

	/** First move past the slop: claim the gesture or let it go for good. */
	private decide(event: TouchEvent | MouseEvent) {
		const deltaX = this.currentX - this.startX;
		const deltaY = this.currentY - this.startY;
		const slop = this.startedOnHandle
			? GESTURE.HANDLE_SLOP
			: this.pointer === 'mouse'
				? GESTURE.MOUSE_SLOP
				: this.startedOnInteractive
					? GESTURE.INTERACTIVE_SLOP
					: GESTURE.RECOGNITION_SLOP;
		if (Math.hypot(deltaX, deltaY) <= slop) return;

		const { placement, allowReverseDrag } = this.options;
		const horizontal = this.isHorizontal();
		const axisTravel = horizontal ? deltaX : deltaY;
		const crossTravel = Math.abs(horizontal ? deltaY : deltaX);
		const towardDismiss =
			placement === 'bottom' || placement === 'right' ? axisTravel > 0 : axisTravel < 0;
		const directionOk = towardDismiss || (!!allowReverseDrag && axisTravel !== 0);
		const alongAxis =
			this.startedOnHandle || Math.abs(axisTravel) >= GESTURE.AXIS_DOMINANCE * crossTravel;
		const scrollOk =
			!this.scrollableContainer || this.isScrollAtDismissBoundary(this.scrollableContainer);

		if (!(directionOk && alongAxis && scrollOk)) {
			this.state = 'released';
			return;
		}

		this.state = 'claimed';
		this.claimX = this.currentX;
		this.claimY = this.currentY;
		this.hasMoved = true;
		event.preventDefault();
		this.reportDragProgress();
	}

	private handleTouchEnd(event: TouchEvent | MouseEvent) {
		// A pending or released gesture was never the drawer's: taps and scrolls
		// finish untouched.
		if (this.state === 'pending' || this.state === 'released') {
			this.reset();
			return;
		}

		if (this.state !== 'claimed' || !this.options.dismissible) return;

		// Dismiss thresholds read raw travel from where the finger went down.
		const deltaY = this.currentY - this.startY;
		const deltaX = this.currentX - this.startX;
		const duration = Date.now() - this.startTime;

		if (this.delegatingToTopDrawer) {
			const dismiss = this.isAboveDismissThreshold(deltaX, deltaY, duration);
			this.reset();
			if (dismiss) dismissTopDrawer();
			return;
		}

		this.swallowClickIfDraggedFromControl(event);

		// The visual offset, and what snap points see, runs from the claim point.
		const offset = this.isHorizontal()
			? this.getDragOffsetXInternal(this.currentX - this.claimX)
			: this.getDragOffsetYInternal(this.currentY - this.claimY);
		const velocity = duration > 0 ? Math.abs(offset) / duration : 0;
		const wasAboveThreshold = this.isAboveDismissThreshold(deltaX, deltaY, duration);

		this.state = 'idle';
		this.startY = 0;
		this.currentY = 0;
		this.startX = 0;
		this.currentX = 0;

		// Allow custom handler to intercept (for snap points)
		if (this.options.onDragEnd?.(offset, velocity, duration)) {
			this.options.onDragChange?.(0, 1, false);
			return;
		}

		this.options.onDragChange?.(0, 1, false);

		if (wasAboveThreshold) {
			this.options.onDismiss();
		}
	}

	private getDragOffsetYInternal(delta: number): number {
		const damped = this.damp(delta);
		if (this.options.placement === 'bottom') {
			return this.options.allowReverseDrag ? damped : Math.max(0, damped);
		} else if (this.options.placement === 'top') {
			return Math.min(0, damped);
		}
		return 0;
	}

	private getDragOffsetXInternal(delta: number): number {
		const damped = this.damp(delta);
		if (this.options.placement === 'right') {
			return Math.max(0, damped);
		} else if (this.options.placement === 'left') {
			return Math.min(0, damped);
		}
		return 0;
	}

	/**
	 * Check if a swipe gesture exceeds the dismiss threshold.
	 * Considers both distance (slow swipe) and velocity (fast swipe).
	 */
	private isAboveDismissThreshold(deltaX: number, deltaY: number, duration: number): boolean {
		const { DISTANCE_SLOW, DISTANCE_FAST, FAST_SWIPE_MAX_DURATION, DISTANCE_BOUNDARY } = GESTURE;

		// Gestures that began at a scroll edge need a deliberate, distance-based
		// pull; the fast-swipe shortcut is dropped so a scroll flick at the top of
		// a list springs back. deltaX/deltaY are raw (undamped) finger travel.
		if (this.startedAtScrollBoundary) {
			switch (this.options.placement) {
				case 'bottom':
					return deltaY > DISTANCE_BOUNDARY;
				case 'top':
					return deltaY < -DISTANCE_BOUNDARY;
				case 'right':
					return deltaX > DISTANCE_BOUNDARY;
				case 'left':
					return deltaX < -DISTANCE_BOUNDARY;
				default:
					return false;
			}
		}

		const isFastSwipe = duration < FAST_SWIPE_MAX_DURATION;

		switch (this.options.placement) {
			case 'bottom':
				return deltaY > DISTANCE_SLOW || (deltaY > DISTANCE_FAST && isFastSwipe);
			case 'top':
				return deltaY < -DISTANCE_SLOW || (deltaY < -DISTANCE_FAST && isFastSwipe);
			case 'right':
				return deltaX > DISTANCE_SLOW || (deltaX > DISTANCE_FAST && isFastSwipe);
			case 'left':
				return deltaX < -DISTANCE_SLOW || (deltaX < -DISTANCE_FAST && isFastSwipe);
			default:
				return false;
		}
	}

	private handleClick(event: MouseEvent) {
		if (this.justDragged) {
			event.preventDefault();
			event.stopPropagation();
			event.stopImmediatePropagation();
		}
	}

	private reportDragProgress() {
		if (!this.options.onDragChange || this.state !== 'claimed') return;

		const offset = this.isHorizontal() ? this.getDragOffsetX() : this.getDragOffsetY();

		let progress = 0;
		if (this.options.placement === 'right') {
			const drawerWidth = this.element?.offsetWidth || 600;
			progress = Math.max(0, Math.min(1, 1 - offset / drawerWidth));
		} else if (this.options.placement === 'left') {
			const drawerWidth = this.element?.offsetWidth || 600;
			progress = Math.max(0, Math.min(1, 1 + offset / drawerWidth));
		} else if (this.options.placement === 'bottom') {
			const drawerHeight = this.element?.offsetHeight || 400;
			progress = Math.max(0, Math.min(1, 1 - offset / drawerHeight));
		} else if (this.options.placement === 'top') {
			const drawerHeight = this.element?.offsetHeight || 400;
			progress = Math.max(0, Math.min(1, 1 + offset / drawerHeight));
		}

		this.options.onDragChange(offset, progress, true);
	}
}
