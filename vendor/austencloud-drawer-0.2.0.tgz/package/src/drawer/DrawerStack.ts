/**
 * DrawerStack - Manages z-index stacking for nested drawers
 *
 * When multiple drawers are open simultaneously, this ensures proper
 * z-index ordering so newer drawers appear on top of older ones.
 *
 * Also manages pull-to-refresh blocking when drawers are open.
 */

const drawerStack: string[] = [];
const dismissCallbacks = new Map<string, () => void>();
const activeCallbacks = new Map<string, () => boolean>();

let baseZIndex = 200;
const Z_INDEX_INCREMENT = 10;

/**
 * Configure the drawer stack's base z-index.
 * Call this once at app startup if you need a different base.
 */
export function configureDrawerStack(options: { baseZIndex?: number }): void {
	if (options.baseZIndex !== undefined) {
		baseZIndex = options.baseZIndex;
	}
}

/**
 * Update pull-to-refresh blocking based on drawer state.
 */
function updatePullToRefreshBlocking(): void {
	if (typeof document === 'undefined') return;

	const html = document.documentElement;

	if (drawerStack.length > 0) {
		html.style.overscrollBehaviorY = 'contain';
	} else {
		html.style.removeProperty('overscroll-behavior-y');
	}
}

/**
 * Generate a unique ID for a drawer instance
 */
export function generateDrawerId(): string {
	return `drawer-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Register a drawer as open and get its z-index
 */
export function registerDrawer(id: string, onDismiss?: () => void, isActive?: () => boolean): number {
	const existingIndex = drawerStack.indexOf(id);
	if (existingIndex !== -1) {
		drawerStack.splice(existingIndex, 1);
		dismissCallbacks.delete(id);
		activeCallbacks.delete(id);
	}

	drawerStack.push(id);

	if (onDismiss) {
		dismissCallbacks.set(id, onDismiss);
	}
	if (isActive) activeCallbacks.set(id, isActive);

	const zIndex = baseZIndex + (drawerStack.length - 1) * Z_INDEX_INCREMENT;
	updatePullToRefreshBlocking();

	return zIndex;
}

/**
 * Unregister a drawer when it closes
 */
export function unregisterDrawer(id: string): void {
	const index = drawerStack.indexOf(id);
	if (index !== -1) {
		drawerStack.splice(index, 1);
	}
	dismissCallbacks.delete(id);
	activeCallbacks.delete(id);
	updatePullToRefreshBlocking();
}

/** A controlled close can precede the effect that unregisters an exiting drawer. */
function topActiveDrawer(): string | undefined {
	for (let index = drawerStack.length - 1; index >= 0; index--) {
		const id = drawerStack[index]!;
		if (activeCallbacks.get(id)?.() !== false) return id;
	}
	return undefined;
}

/**
 * Dismiss the topmost drawer in the stack.
 */
export function dismissTopDrawer(): boolean {
	const topDrawerId = topActiveDrawer();
	if (!topDrawerId) return false;
	const dismissCallback = dismissCallbacks.get(topDrawerId);

	if (dismissCallback) {
		dismissCallback();
		return true;
	}

	return false;
}

/**
 * Check if a drawer is the topmost drawer
 */
export function isTopDrawer(id: string): boolean {
	return topActiveDrawer() === id;
}

/** An Escape already handled by one drawer must not reach a newly opened nested drawer. */
export function claimEscape(event: Pick<KeyboardEvent, 'defaultPrevented' | 'preventDefault'>, id: string): boolean {
	if (event.defaultPrevented || !isTopDrawer(id)) return false;
	event.preventDefault();
	return true;
}

/**
 * Get the current drawer stack depth
 */
export function getStackDepth(): number {
	return drawerStack.length;
}

/**
 * Get z-index for a specific drawer
 */
export function getDrawerZIndex(id: string): number {
	const index = drawerStack.indexOf(id);
	if (index === -1) return baseZIndex;
	return baseZIndex + index * Z_INDEX_INCREMENT;
}

/**
 * Check if any drawer is currently open
 */
export function hasOpenDrawers(): boolean {
	return drawerStack.length > 0;
}
