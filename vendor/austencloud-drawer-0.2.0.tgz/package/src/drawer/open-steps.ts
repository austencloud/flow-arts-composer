/**
 * The order of a drawer's open.
 *
 * Marking the page behind the drawer inert and moving focus into it makes the
 * browser restyle the whole page before it can paint, which took 100-150 ms on
 * a busy app page. Done in the frame that adds the open class, that work held
 * the slide back. So the slide starts first and the focus trap follows on the
 * next frame, while the compositor is already moving the sheet.
 */
export interface DrawerOpenSteps {
	/** Shows the dialog and adds the open class that starts the slide. */
	startSlide(): void;
	/** Marks the background inert and moves focus into the drawer. */
	trapFocus(): void;
	/** False once a later open or close has replaced this one. */
	isCurrent(): boolean;
}

export function runDrawerOpen(
	steps: DrawerOpenSteps,
	nextFrame: (run: () => void) => void = requestAnimationFrame
): void {
	if (!steps.isCurrent()) return;
	steps.startSlide();
	nextFrame(() => {
		if (steps.isCurrent()) steps.trapFocus();
	});
}
