# @austencloud/drawer

`Drawer` is a Svelte 5 drawer with focus management, gestures, snap points, and a shared close lifecycle.

## Closing

Use the component's exported `requestClose(reason?)` method for application close buttons. It returns `false` when the drawer is already closed or `onBeforeClose(reason)` returns `false`; otherwise it sets the bound `isOpen` value to `false` and returns `true`. The optional reason defaults to `programmatic`.

Backdrop, Escape, swipe, and snap-to-zero closes use the same synchronous guard. `onclose` runs once when an accepted close changes `isOpen` to `false`, with `{ detail: { reason } }`. A parent can also set bound `isOpen` to `false` directly; this is an uncancellable programmatic close and still emits one close notification. Use that direct path for authoritative external state changes.

`onBeforeClose` is synchronous. To show a confirmation drawer, open it inside the callback and return `false`; after confirmation, call `requestClose()` again or set `isOpen` to `false` directly if that close must bypass the guard.
