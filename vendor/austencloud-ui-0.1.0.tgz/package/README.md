# @austencloud/ui

Svelte 5 controls shared by AustenCloud apps. The package owns control behavior and accessibility. Each app owns its theme, messages, timers, and domain icons.

```svelte
<script lang="ts">
  import {
    Button,
    SegmentedControl,
    FormField,
    ToastRegion,
  } from "@austencloud/ui";
  let selected = $state("one");
</script>

<Button variant="primary" onclick={save}>Save</Button>
<SegmentedControl
  options={[
    { value: "one", label: "One" },
    { value: "two", label: "Two" },
  ]}
  value={selected}
  onchange={(value) => (selected = value)}
  semantics="radiogroup"
  ariaLabel="Choice"
/>
<FormField label="Name" help="Shown on your profile">
  {#snippet children(field)}
    <input
      id={field.id}
      aria-describedby={field.describedBy}
      aria-invalid={field.invalid}
      required={field.required}
      disabled={field.disabled}
    />
  {/snippet}
</FormField>
<ToastRegion items={notices} ondismiss={dismiss} />
```

`Button` renders a native button or anchor when `href` is provided. `disabled` and `loading` prevent activation. It accepts native button attributes, `class`, `style`, `variant` (`primary`, `secondary`, `quiet`, `outline`, `ghost`, `danger`), `size`, and `fullWidth`. Icons are child snippets. Its minimum target is 44px.

`SegmentedControl` accepts string or number values. `button-group` uses pressed buttons; `tabs` and `radiogroup` have arrow, Home, and End navigation, skip disabled options, and move focus with selection. Use `columns` for a grid; Up and Down then move by row. `optionContent` is a snippet receiving each value for app icons or custom labels. Options also support `shortLabel`, `count`, `tone`, and tab `id`/`controls`. All segments have `data-selected` and `data-tone` hooks.

`FormField` gives its child snippet `{ id, describedBy, invalid, required, disabled }`. Apply these to the native control. It generates stable help and error associations and renders the error as an alert.

`ToastRegion` receives `{ id, message, tone? }[]`, `ondismiss(id)`, optional `onpause(id)` and `onresume(id)`, and optional `action(item)` snippet. The caller owns notice lifecycle and timers. The region announces additions politely; dismissal is a 44px button.

## Theme contract

Set `--ui-*` custom properties on an app root. Core tokens: `--ui-accent`, `--ui-accent-hover`, `--ui-on-accent`, `--ui-surface`, `--ui-surface-hover`, `--ui-stroke`, `--ui-text`, `--ui-text-muted`, `--ui-focus`, `--ui-error`, `--ui-success`, `--ui-radius`, `--ui-motion-duration`, `--ui-font-size`, and `--ui-support-size`. Button and segment tokens override them locally: `--ui-button-bg`, `--ui-button-border`, `--ui-button-text`, `--ui-button-hover`, `--ui-segment-selected-bg`, and `--ui-segment-selected-text`. Essential text stays at least 14px; help and badges stay at least 12px. Focus rings and reduced motion are built in. Apps must choose theme colors with sufficient contrast for their own backgrounds.
