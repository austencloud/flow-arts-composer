<script lang="ts" generics="T extends string | number">
  import { flip } from "svelte/animate";
  import { flipDuration, popIn, leave } from "@austencloud/motion";
  import {
    activatedSegmentValue,
    nextSegmentIndex,
    type SegmentOption,
  } from "./segmented-keyboard.js";
  import type { SegmentedControlProps } from "./segmented-types.js";
  let {
    options,
    value,
    onchange,
    semantics = "button-group",
    ariaLabel,
    ariaLabelledby,
    optionContent,
    columns,
    density = "standard",
    size = "md",
    toggleOnActivate = false,
    class: className = "",
    optionClass = "",
    style = "",
    ghostKind,
  }: SegmentedControlProps<T> = $props();

  let root: HTMLDivElement;
  const selectedIndex = $derived(
    options.findIndex((option) => option.value === value),
  );
  const firstEnabled = $derived(
    options.findIndex((option) => !option.disabled),
  );
  const focusIndex = $derived(
    selectedIndex >= 0 && !options[selectedIndex]?.disabled
      ? selectedIndex
      : firstEnabled,
  );
  const gridColumns = $derived(
    columns && columns > 0 && columns < options.length ? columns : undefined,
  );

  function select(option: SegmentOption<T>) {
    const selected = activatedSegmentValue(
      options,
      value,
      option,
      toggleOnActivate,
    );
    if (selected !== null) onchange(selected);
  }

  function keydown(event: KeyboardEvent, index: number) {
    if (semantics === "button-group") return;
    const target = nextSegmentIndex(options, index, event.key, gridColumns);
    if (target === null) return;
    event.preventDefault();
    event.stopPropagation();
    root
      .querySelectorAll<HTMLButtonElement>("button[data-segment]")
      [target]?.focus();
    const option = options[target];
    if (option) select(option);
  }

  function surfacePointerUp(event: PointerEvent) {
    if (
      !toggleOnActivate ||
      (event.target instanceof Element &&
        event.target.closest("button[data-segment]"))
    )
      return;
    const enabled = options.filter((option) => !option.disabled);
    if (enabled.length === 2) {
      const target = enabled.find((option) => option.value !== value);
      if (target) onchange(target.value);
    }
  }
</script>

<div
  bind:this={root}
  class="ui-segments {className}"
  {style}
  data-density={density}
  data-size={size}
  data-grid={gridColumns ? "true" : undefined}
  role={semantics === "tabs"
    ? "tablist"
    : semantics === "radiogroup"
      ? "radiogroup"
      : ariaLabel || ariaLabelledby
        ? "group"
        : undefined}
  aria-orientation={semantics === "button-group" || gridColumns
    ? undefined
    : "horizontal"}
  aria-label={ariaLabel}
  aria-labelledby={ariaLabelledby}
  style:--ui-segment-columns={gridColumns ?? options.length}
  onpointerup={surfacePointerUp}
>
  {#each options as option, index (option.value)}
    <button
      type="button"
      class={optionClass}
      class:selected={value === option.value}
      data-segment=""
      data-selected={value === option.value ? "true" : undefined}
      data-tone={option.tone}
      data-ghost={ghostKind && value !== option.value && !option.disabled
        ? "safe"
        : undefined}
      data-ghost-kind={ghostKind && value !== option.value && !option.disabled
        ? ghostKind
        : undefined}
      role={semantics === "tabs"
        ? "tab"
        : semantics === "radiogroup"
          ? "radio"
          : undefined}
      id={option.id}
      aria-controls={semantics === "tabs" ? option.controls : undefined}
      aria-selected={semantics === "tabs" ? value === option.value : undefined}
      aria-checked={semantics === "radiogroup"
        ? value === option.value
        : undefined}
      aria-pressed={semantics === "button-group"
        ? value === option.value
        : undefined}
      aria-label={option.ariaLabel ?? option.label}
      title={option.title ?? option.label}
      style={option.style}
      tabindex={semantics === "button-group"
        ? 0
        : index === focusIndex
          ? 0
          : -1}
      disabled={option.disabled}
      onclick={() => select(option)}
      onkeydown={(event) => keydown(event, index)}
      in:popIn
      out:leave
      animate:flip={{ duration: flipDuration() }}
    >
      {#if optionContent}{@render optionContent(
          option.value,
        )}{:else}{option.shortLabel ?? option.label}{/if}
      {#if option.count != null}<span class="count">{option.count}</span>{/if}
    </button>
  {/each}
</div>

<style>
  .ui-segments {
    display: flex;
    position: relative;
    box-sizing: border-box;
    width: 100%;
    gap: 2px;
    padding: 3px;
    border: 1px solid var(--ui-stroke, #777);
    border-radius: var(--ui-radius, 8px);
    background: var(--ui-surface, transparent);
  }
  .ui-segments[data-grid="true"] {
    display: grid;
    grid-template-columns: repeat(var(--ui-segment-columns), minmax(0, 1fr));
  }
  button {
    flex: 1 1 0;
    min-width: 44px;
    min-height: 44px;
    padding: 0.5rem 0.7rem;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 0.35rem;
    border: 1px solid transparent;
    border-radius: calc(var(--ui-radius, 8px) - 2px);
    background: transparent;
    color: var(--ui-text, currentColor);
    font: inherit;
    font-size: max(14px, var(--ui-font-size, 14px));
    cursor: pointer;
    transition:
      background-color var(--ui-motion-duration, var(--duration-fast, 150ms))
        var(--ease-standard, ease),
      color var(--ui-motion-duration, var(--duration-fast, 150ms))
        var(--ease-standard, ease);
  }
  button[data-selected="true"] {
    background: var(--ui-segment-selected-bg, var(--ui-accent, #6750b8));
    color: var(--ui-segment-selected-text, var(--ui-on-accent, white));
  }
  button[data-tone="blue"][data-selected="true"] {
    background: var(
      --ui-tone-blue-wash,
      var(--ui-segment-selected-bg, var(--ui-accent, #6750b8))
    );
  }
  button[data-tone="red"][data-selected="true"] {
    background: var(
      --ui-tone-red-wash,
      var(--ui-segment-selected-bg, var(--ui-accent, #6750b8))
    );
  }
  button[data-tone="both"][data-selected="true"] {
    background: var(
      --ui-tone-both-wash,
      var(--ui-segment-selected-bg, var(--ui-accent, #6750b8))
    );
  }
  button[data-tone="accent"][data-selected="true"] {
    background: var(
      --ui-tone-accent-wash,
      var(--ui-segment-selected-bg, var(--ui-accent, #6750b8))
    );
  }
  button:hover:not(:disabled):not([data-selected="true"]) {
    background: var(--ui-surface-hover, rgba(127, 127, 127, 0.15));
  }
  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  button:focus-visible {
    outline: 3px solid var(--ui-focus, var(--ui-accent, #6750b8));
    outline-offset: 2px;
    z-index: 1;
  }
  .count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 1.1rem;
    padding: 0.05rem 0.3rem;
    border-radius: 99px;
    background: color-mix(in srgb, currentColor 14%, transparent);
    font-size: max(12px, var(--ui-support-size, 12px));
    font-variant-numeric: tabular-nums;
  }
  .ui-segments[data-density="tight"] button {
    padding-inline: 0.25rem;
  }
  .ui-segments[data-density="compact"] button {
    padding-inline: 0.4rem;
  }
  @media (prefers-reduced-motion: reduce) {
    button {
      transition: none;
    }
  }
</style>
