export type SegmentValue = string | number;
export interface SegmentOption<T extends SegmentValue = SegmentValue> {
  value: T;
  label: string;
  shortLabel?: string;
  ariaLabel?: string;
  count?: number | null;
  disabled?: boolean;
  tone?: string;
  id?: string;
  controls?: string;
  title?: string;
  style?: string;
}

export function activatedSegmentValue<T extends SegmentValue>(
  options: SegmentOption<T>[],
  currentValue: T,
  activated: SegmentOption<T>,
  toggleOnActivate: boolean,
): T | null {
  if (activated.disabled) return null;
  if (toggleOnActivate) {
    const enabled = options.filter((option) => !option.disabled);
    if (enabled.length === 2) {
      return (
        enabled.find((option) => option.value !== currentValue)?.value ??
        activated.value
      );
    }
  }
  return activated.value;
}

export function nextSegmentIndex<T extends SegmentValue>(
  options: SegmentOption<T>[],
  current: number,
  key: string,
  columns?: number,
): number | null {
  const enabled = options.flatMap((option, index) =>
    option.disabled ? [] : [index],
  );
  if (!enabled.includes(current)) return null;
  if (columns && (key === "ArrowUp" || key === "ArrowDown")) {
    const direction = key === "ArrowDown" ? 1 : -1;
    let target = current + direction * columns;
    while (target >= 0 && target < options.length) {
      if (!options[target]?.disabled) return target;
      target += direction;
    }
    return null;
  }
  const position = enabled.indexOf(current);
  switch (key) {
    case "ArrowLeft":
      return enabled[(position - 1 + enabled.length) % enabled.length] ?? null;
    case "ArrowRight":
      return enabled[(position + 1) % enabled.length] ?? null;
    case "Home":
      return enabled[0] ?? null;
    case "End":
      return enabled.at(-1) ?? null;
    default:
      return null;
  }
}
