export function createToastPauseState<Id extends string | number>(
  onpause: (id: Id) => void,
  onresume: (id: Id) => void,
) {
  const state = new Map<Id, { pointer: boolean; focus: boolean }>();
  return {
    set(id: Id, reason: "pointer" | "focus", active: boolean) {
      const entry = state.get(id) ?? { pointer: false, focus: false };
      const wasPaused = entry.pointer || entry.focus;
      entry[reason] = active;
      const isPaused = entry.pointer || entry.focus;
      if (isPaused) state.set(id, entry);
      else state.delete(id);
      if (!wasPaused && isPaused) onpause(id);
      if (wasPaused && !isPaused) onresume(id);
    },
    retain(ids: readonly Id[]) {
      const live = new Set(ids);
      for (const id of state.keys()) if (!live.has(id)) state.delete(id);
    },
  };
}
