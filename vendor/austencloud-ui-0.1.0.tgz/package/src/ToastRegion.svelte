<script lang="ts">
  import type { Snippet } from "svelte";
  import type { ToastItem } from "./toast-types.js";
  import { createToastPauseState } from "./toast-pause.js";
  interface Props {
    items: ToastItem[];
    ondismiss: (id: ToastItem["id"]) => void;
    onpause?: (id: ToastItem["id"]) => void;
    onresume?: (id: ToastItem["id"]) => void;
    action?: Snippet<[ToastItem]>;
    dismissLabel?: string;
    class?: string;
  }
  let {
    items,
    ondismiss,
    onpause,
    onresume,
    action,
    dismissLabel = "Dismiss notification",
    class: className = "",
  }: Props = $props();
  const pauseState = createToastPauseState<ToastItem["id"]>(
    (id) => onpause?.(id),
    (id) => onresume?.(id),
  );
  $effect(() => pauseState.retain(items.map((item) => item.id)));
</script>

<div
  class="ui-toasts {className}"
  aria-live="polite"
  aria-relevant="additions text"
>
  {#each items as item (item.id)}
    <div
      class="toast"
      role="group"
      data-tone={item.tone ?? "info"}
      onpointerenter={() => pauseState.set(item.id, "pointer", true)}
      onpointerleave={() => pauseState.set(item.id, "pointer", false)}
      onfocusin={() => pauseState.set(item.id, "focus", true)}
      onfocusout={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node))
          pauseState.set(item.id, "focus", false);
      }}
    >
      <span class="message">{item.message}</span>
      {#if action}{@render action(item)}{/if}
      <button
        type="button"
        aria-label={dismissLabel}
        onclick={() => ondismiss(item.id)}>&times;</button
      >
    </div>
  {/each}
</div>

<style>
  .ui-toasts {
    display: grid;
    gap: 0.5rem;
    color: var(--ui-text, currentColor);
    font-size: max(14px, var(--ui-font-size, 14px));
  }
  .toast {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    min-width: 0;
    padding: 0.4rem 0.5rem 0.4rem 0.8rem;
    border: 1px solid var(--ui-stroke, currentColor);
    border-radius: var(--ui-radius, 8px);
    background: var(--ui-surface, #222);
    box-shadow: var(--ui-toast-shadow, 0 4px 18px rgba(0, 0, 0, 0.2));
  }
  .toast[data-tone="error"] {
    border-color: var(--ui-error, #b3261e);
  }
  .toast[data-tone="success"] {
    border-color: var(--ui-success, #17834d);
  }
  .message {
    flex: 1;
    min-width: 0;
    overflow-wrap: anywhere;
  }
  button {
    min-width: 44px;
    min-height: 44px;
    border: 0;
    border-radius: var(--ui-radius, 8px);
    background: transparent;
    color: inherit;
    font: inherit;
    font-size: 24px;
    cursor: pointer;
  }
  button:hover {
    background: var(--ui-surface-hover, rgba(127, 127, 127, 0.15));
  }
  button:focus-visible {
    outline: 3px solid var(--ui-focus, var(--ui-accent, #6750b8));
    outline-offset: 2px;
  }
</style>
