export interface ToastItem {
  id: string | number;
  message: string;
  tone?: "info" | "success" | "warning" | "error";
}
