<script lang="ts">
  import type { Snippet } from "svelte";
  import type {
    HTMLAnchorAttributes,
    HTMLButtonAttributes,
  } from "svelte/elements";

  type Variant =
    | "primary"
    | "secondary"
    | "quiet"
    | "outline"
    | "ghost"
    | "danger";
  interface Props extends Omit<HTMLButtonAttributes, "children" | "onclick"> {
    children?: Snippet;
    variant?: Variant;
    size?: "sm" | "md" | "lg";
    href?: string;
    target?: string;
    rel?: string;
    loading?: boolean;
    fullWidth?: boolean;
    ref?: HTMLButtonElement | null;
    onclick?: (event: MouseEvent) => void;
  }

  let {
    children,
    variant = "secondary",
    size = "md",
    href,
    target,
    rel,
    loading = false,
    disabled = false,
    fullWidth = false,
    type = "button",
    ref = $bindable(null),
    class: className = "",
    style,
    onclick,
    ...rest
  }: Props = $props();

  const unavailable = $derived(disabled || loading);
  const anchorRest = $derived(rest as unknown as HTMLAnchorAttributes);
</script>

{#if href !== undefined}
  <a
    {...anchorRest}
    href={unavailable ? undefined : href}
    {target}
    {rel}
    class="ui-button {className}"
    {style}
    data-variant={variant}
    data-size={size}
    data-loading={loading || undefined}
    data-full-width={fullWidth || undefined}
    aria-disabled={unavailable || undefined}
    aria-busy={loading || undefined}
    tabindex={unavailable ? -1 : rest.tabindex}
    onclick={(event) => {
      if (unavailable) event.preventDefault();
      else onclick?.(event);
    }}
  >
    {#if loading}<span class="spinner" aria-hidden="true"></span>{/if}
    {#if children}{@render children()}{/if}
  </a>
{:else}
  <button
    bind:this={ref}
    class="ui-button {className}"
    {style}
    data-variant={variant}
    data-size={size}
    data-loading={loading || undefined}
    data-full-width={fullWidth || undefined}
    {type}
    disabled={unavailable}
    aria-busy={loading || undefined}
    {onclick}
    {...rest}
  >
    {#if loading}<span class="spinner" aria-hidden="true"></span>{/if}
    {#if children}{@render children()}{/if}
  </button>
{/if}

<style>
  .ui-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    box-sizing: border-box;
    min-width: 44px;
    min-height: 44px;
    padding: 0.625rem 1rem;
    border: 1px solid var(--ui-button-border, var(--ui-stroke, currentColor));
    border-radius: var(--ui-radius, 8px);
    background: var(--ui-button-bg, var(--ui-surface, transparent));
    color: var(--ui-button-text, var(--ui-text, currentColor));
    font: inherit;
    font-size: max(14px, var(--ui-font-size, 14px));
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition:
      background-color var(--ui-motion-duration, var(--duration-fast, 150ms))
        var(--ease-standard, ease),
      border-color var(--ui-motion-duration, var(--duration-fast, 150ms))
        var(--ease-standard, ease),
      color var(--ui-motion-duration, var(--duration-fast, 150ms))
        var(--ease-standard, ease);
  }
  .ui-button[data-variant="primary"] {
    background: var(--ui-accent, #6750b8);
    border-color: var(--ui-accent, #6750b8);
    color: var(--ui-on-accent, white);
  }
  .ui-button[data-variant="quiet"],
  .ui-button[data-variant="ghost"] {
    background: var(--ui-quiet-bg, transparent);
    color: var(--ui-text, currentColor);
  }
  .ui-button[data-variant="outline"] {
    background: transparent;
  }
  .ui-button[data-variant="danger"] {
    background: var(--ui-error, #b3261e);
    border-color: var(--ui-error, #b3261e);
    color: var(--ui-on-error, white);
  }
  .ui-button[data-full-width="true"] {
    width: 100%;
  }
  .ui-button[disabled],
  .ui-button[aria-disabled="true"] {
    opacity: 0.55;
    cursor: not-allowed;
  }
  .ui-button:hover:not(:disabled):not([aria-disabled="true"]) {
    background: var(
      --ui-button-hover,
      var(
        --ui-surface-hover,
        var(--ui-button-bg, var(--ui-surface, transparent))
      )
    );
  }
  .ui-button[data-variant="primary"]:hover:not(:disabled):not(
      [aria-disabled="true"]
    ) {
    background: var(--ui-accent-hover, var(--ui-accent, #6750b8));
  }
  .ui-button[data-variant="danger"]:hover:not(:disabled):not(
      [aria-disabled="true"]
    ) {
    background: var(--ui-error-hover, var(--ui-error, #b3261e));
  }
  .ui-button:focus-visible {
    outline: 3px solid var(--ui-focus, var(--ui-accent, #6750b8));
    outline-offset: 3px;
  }
  .spinner {
    width: 1em;
    height: 1em;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: spin var(--ui-spinner-duration, var(--duration-scene, 0.8s))
      linear infinite;
  }
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
  @media (prefers-reduced-motion: reduce) {
    .ui-button {
      transition: none;
    }
    .spinner {
      animation-duration: 2s;
    }
  }
</style>
