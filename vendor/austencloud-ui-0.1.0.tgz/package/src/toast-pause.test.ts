import { describe, expect, it } from "vitest";
import { createToastPauseState } from "./toast-pause.js";

describe("toast pause coordination", () => {
  it("resumes only after pointer and focus both leave", () => {
    const events: string[] = [];
    const pause = createToastPauseState<number>(
      (id) => events.push(`pause ${id}`),
      (id) => events.push(`resume ${id}`),
    );
    pause.set(1, "pointer", true);
    pause.set(1, "focus", true);
    pause.set(1, "pointer", false);
    expect(events).toEqual(["pause 1"]);
    pause.set(1, "focus", false);
    expect(events).toEqual(["pause 1", "resume 1"]);
  });
  it("forgets removed notices before IDs can be reused", () => {
    const events: string[] = [];
    const pause = createToastPauseState<string>(
      (id) => events.push(`pause ${id}`),
      (id) => events.push(`resume ${id}`),
    );
    pause.set("notice", "pointer", true);
    pause.retain([]);
    pause.set("notice", "focus", true);
    expect(events).toEqual(["pause notice", "pause notice"]);
  });
});
