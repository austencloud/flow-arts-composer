<script lang="ts">
  import type { Snippet } from "svelte";

  export interface ControlAttrs {
    id: string;
    describedBy?: string;
    invalid: boolean;
    required: boolean;
    disabled: boolean;
  }
  interface Props {
    label: string;
    children: Snippet<[ControlAttrs]>;
    help?: string;
    error?: string;
    required?: boolean;
    disabled?: boolean;
    id?: string;
    class?: string;
    style?: string;
  }
  let {
    label,
    children,
    help,
    error,
    required = false,
    disabled = false,
    id,
    class: className = "",
    style,
  }: Props = $props();
  const generatedId = $props.id();
  const controlId = $derived(id ?? generatedId);
  const describedBy = $derived(
    [help ? `${controlId}-help` : null, error ? `${controlId}-error` : null]
      .filter(Boolean)
      .join(" ") || undefined,
  );
  const attrs = $derived({
    id: controlId,
    describedBy,
    invalid: !!error,
    required,
    disabled,
  });
</script>

<div class="ui-field {className}" {style} data-invalid={error ? "true" : undefined}>
  <label for={controlId}
    >{label}{#if required}<span class="required" aria-hidden="true">
        *</span
      >{/if}</label
  >
  {@render children(attrs)}
  {#if help}<span id="{controlId}-help" class="help">{help}</span>{/if}
  {#if error}<span id="{controlId}-error" class="error" role="alert"
      >{error}</span
    >{/if}
</div>

<style>
  .ui-field {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    min-width: 0;
    color: var(--ui-text, currentColor);
    font-size: max(14px, var(--ui-font-size, 14px));
  }
  label {
    font-weight: 600;
  }
  .required,
  .error {
    color: var(--ui-error, #b3261e);
  }
  .help,
  .error {
    font-size: max(12px, var(--ui-support-size, 12px));
  }
  .help {
    color: var(--ui-text-muted, var(--ui-text, currentColor));
  }
</style>
