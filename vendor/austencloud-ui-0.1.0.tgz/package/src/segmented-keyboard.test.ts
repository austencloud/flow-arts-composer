import { describe, expect, it } from "vitest";
import {
  activatedSegmentValue,
  nextSegmentIndex,
} from "./segmented-keyboard.js";

const options = [
  { value: 1, label: "One" },
  { value: 2, label: "Two", disabled: true },
  { value: 3, label: "Three" },
  { value: 4, label: "Four" },
];

describe("segmented keyboard selection", () => {
  it("wraps, skips disabled options, and reaches endpoints", () => {
    expect(nextSegmentIndex(options, 0, "ArrowRight")).toBe(2);
    expect(nextSegmentIndex(options, 0, "ArrowLeft")).toBe(3);
    expect(nextSegmentIndex(options, 3, "Home")).toBe(0);
    expect(nextSegmentIndex(options, 0, "End")).toBe(3);
    expect(nextSegmentIndex(options, 1, "ArrowRight")).toBeNull();
  });
  it("moves by grid row while skipping disabled cells", () => {
    expect(nextSegmentIndex(options, 0, "ArrowDown", 2)).toBe(2);
    expect(nextSegmentIndex(options, 3, "ArrowUp", 2)).toBe(0);
    expect(nextSegmentIndex(options, 2, "ArrowDown", 2)).toBeNull();
  });
  it("ignores disabled activation and toggles a two-value switch", () => {
    expect(activatedSegmentValue(options, 1, options[1]!, false)).toBeNull();
    const modes = [
      { value: "off", label: "Off" },
      { value: "on", label: "On" },
    ];
    expect(activatedSegmentValue(modes, "off", modes[0]!, true)).toBe("on");
    expect(activatedSegmentValue(modes, "on", modes[0]!, true)).toBe("off");
  });
});
