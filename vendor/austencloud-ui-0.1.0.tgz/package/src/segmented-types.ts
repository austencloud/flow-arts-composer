import type { Snippet } from "svelte";
import type { SegmentOption, SegmentValue } from "./segmented-keyboard.js";

export interface SegmentedControlProps<T extends SegmentValue> {
  options: SegmentOption<T>[];
  value: T;
  onchange: (value: T) => void;
  semantics?: "button-group" | "tabs" | "radiogroup";
  ariaLabel?: string;
  ariaLabelledby?: string;
  optionContent?: Snippet<[T]>;
  columns?: number;
  density?: "standard" | "compact" | "tight";
  size?: "sm" | "md";
  toggleOnActivate?: boolean;
  class?: string;
  optionClass?: string;
  style?: string;
  ghostKind?: string;
}
