<!-- Sections List Component -->
<!-- Container for section buttons that can slide in/out.
     When `groups` is provided AND sections carry `groupId`, renders collapsible
     group headers. Otherwise renders the flat list, unchanged. -->
<script lang="ts">
  import { slide, fly } from 'svelte/transition';
  import { cubicOut } from 'svelte/easing';
  import type { Snippet } from 'svelte';
  import type { Section, SectionGroup } from '../types';
  import SectionButton from './SectionButton.svelte';

  let {
    sections,
    groups,
    currentSection,
    moduleId,
    isActive,
    isCollapsed = false,
    onSectionClick,
    onSectionContextMenu,
    celebrateAppearance = false,
    badgeCounts = {},
    translateSectionLabel,
    renderIcon,
  } = $props<{
    sections: Section[];
    groups?: SectionGroup[] | undefined;
    currentSection: string;
    moduleId: string;
    isActive: boolean;
    isCollapsed?: boolean | undefined;
    onSectionClick: (moduleId: string, section: Section, e?: MouseEvent) => void;
    onSectionContextMenu?: ((e: MouseEvent, moduleId: string, section: Section) => void) | undefined;
    celebrateAppearance?: boolean | undefined;
    badgeCounts?: Record<string, number> | undefined;
    translateSectionLabel?: ((moduleId: string, sectionId: string, fallback: string) => string) | undefined;
    renderIcon?: Snippet<[name: string, size: number]> | undefined;
  }>();

  // Grouping only kicks in when the module supplies groups AND at least one
  // section is tagged. One tree in both states: in the rail the group headers
  // fold away and every group opens, which leaves a plain icon list. Rows morph
  // on the width's clock, so nothing remounts when the sidebar moves.
  const useGroups = $derived(
    !!(groups && groups.length > 0 && sections.some((s: Section) => s.groupId))
  );

  const grouped = $derived.by(() => {
    if (!useGroups || !groups) return [];
    return groups
      .map((g: SectionGroup) => ({
        group: g,
        items: sections.filter((s: Section) => s.groupId === g.id),
      }))
      .filter((entry: { items: Section[] }) => entry.items.length > 0);
  });

  const ungrouped = $derived.by(() => {
    if (!useGroups || !groups) return [];
    const ids = new Set(groups.map((g: SectionGroup) => g.id));
    return sections.filter((s: Section) => !s.groupId || !ids.has(s.groupId));
  });

  const activeGroupId = $derived(
    useGroups ? sections.find((s: Section) => s.id === currentSection)?.groupId : undefined
  );

  const storeKey = $derived(`nav-expanded-${moduleId}`);

  function loadExpanded(key: string): Record<string, boolean> {
    if (typeof localStorage === 'undefined') return {};
    try {
      return JSON.parse(localStorage.getItem(key) || '{}');
    } catch {
      return {};
    }
  }

  let expanded = $state<Record<string, boolean>>(loadExpanded(`nav-expanded-${moduleId}`));

  $effect(() => {
    if (activeGroupId && !expanded[activeGroupId]) {
      expanded[activeGroupId] = true;
    }
  });

  $effect(() => {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(storeKey, JSON.stringify(expanded));
  });

  function toggle(id: string) {
    expanded[id] = !expanded[id];
  }
</script>

<div
  class="sections-list"
  class:celebrate={celebrateAppearance}
  class:collapsed={isCollapsed}
  transition:slide={{ duration: 200 }}
>
  {#if useGroups}
    {#each grouped as { group, items } (group.id)}
      {@const open = isCollapsed || (expanded[group.id] ?? false)}
      <div class="fold" class:closed={isCollapsed} inert={isCollapsed}>
        <div class="fold-clip">
          <button
            class="group-header"
            class:collapsed={isCollapsed}
            style="--group-color: {group.color || 'var(--muted-foreground)'};"
            onclick={() => toggle(group.id)}
            aria-expanded={expanded[group.id] ?? false}
          >
            <i class="fas fa-chevron-right chev" class:open={expanded[group.id]} aria-hidden="true"></i>
            {#if group.icon}
              <span class="group-icon">
                {#if renderIcon}{@render renderIcon(group.icon, 18)}{:else}{@html group.icon}{/if}
              </span>
            {/if}
            <span class="group-label">{group.label}</span>
            <span class="group-count">{items.length}</span>
          </button>
        </div>
      </div>
      <div class="fold" class:closed={!open} inert={!open}>
        <div class="fold-clip">
          <div
            class="group-body"
            class:collapsed={isCollapsed}
            style="--group-color: {group.color || 'var(--muted-foreground)'};"
          >
            {#each items as section (section.id)}
              <SectionButton
                {section}
                {moduleId}
                {isCollapsed}
                isActive={currentSection === section.id && isActive}
                onClick={(e: MouseEvent) => onSectionClick(moduleId, section, e)}
                onContextMenu={onSectionContextMenu ? (e) => onSectionContextMenu(e, moduleId, section) : undefined}
                badgeCount={badgeCounts[section.id] || 0}
                {translateSectionLabel}
                {renderIcon}
              />
            {/each}
          </div>
        </div>
      </div>
    {/each}

    {#each ungrouped as section (section.id)}
      <SectionButton
        {section}
        {moduleId}
        {isCollapsed}
        isActive={currentSection === section.id && isActive}
        onClick={(e: MouseEvent) => onSectionClick(moduleId, section, e)}
        onContextMenu={onSectionContextMenu ? (e) => onSectionContextMenu(e, moduleId, section) : undefined}
        badgeCount={badgeCounts[section.id] || 0}
        {translateSectionLabel}
        {renderIcon}
      />
    {/each}
  {:else}
    {#each sections as section, i}
      {@const isSectionActive = currentSection === section.id && isActive}

      <div
        class="section-item"
        class:celebrate={celebrateAppearance}
        style="--item-index: {i};"
        in:fly={{
          x: celebrateAppearance ? -30 : -10,
          y: celebrateAppearance ? 10 : 0,
          delay: celebrateAppearance ? 150 + i * 100 : 50 + i * 30,
          duration: celebrateAppearance ? 400 : 200,
          easing: cubicOut,
        }}
      >
        <SectionButton
          {section}
          {moduleId}
          {isCollapsed}
          isActive={isSectionActive}
          onClick={(e: MouseEvent) => onSectionClick(moduleId, section, e)}
          onContextMenu={onSectionContextMenu ? (e) => onSectionContextMenu(e, moduleId, section) : undefined}
          badgeCount={badgeCounts[section.id] || 0}
          {translateSectionLabel}
          {renderIcon}
        />
      </div>
    {/each}
  {/if}
</div>

<style>
  /* ============================================================================
     SECTIONS LIST
     ============================================================================ */
  .sections-list {
    margin-top: 6px;
    /* The rail<->expanded inset lives here — the single horizontal motion of the
       whole tab list. Expanded insets tabs 10px right of the module icon; rail
       zeroes it so tab icons sit directly under the module (x=32). Transitioning
       padding-left slides every tab together, no snap. */
    padding-left: 10px;
    transition: padding-left var(--duration-emphasis) var(--ease-out);
  }

  .sections-list.collapsed {
    padding-left: 0;
  }

  /* ============================================================================
     FOLD: a row of the tree that opens and closes in height on the width's clock.
     Clips only vertically, with room for a focus ring, so a row's hover nudge and
     focus ring still paint at rest.
     ============================================================================ */
  .fold {
    display: grid;
    grid-template-rows: 1fr;
    transition: grid-template-rows var(--duration-emphasis) var(--ease-out);
  }

  .fold.closed {
    grid-template-rows: 0fr;
  }

  .fold-clip {
    min-width: 0;
    min-height: 0;
    overflow-y: clip;
    overflow-clip-margin: 2px;
  }

  /* ============================================================================
     COLLAPSIBLE GROUP HEADER
     ============================================================================ */
  .group-header {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 9px 12px;
    margin: 6px 0 2px;
    background: transparent;
    border: none;
    border-radius: 9px;
    color: var(--theme-text, #e6e8ee);
    cursor: pointer;
    font-size: var(--font-size-compact);
    font-weight: 650;
    letter-spacing: -0.005em;
    white-space: nowrap;
    overflow: hidden;
    transition:
      background var(--duration-fast) ease,
      opacity var(--duration-normal) var(--ease-out);
  }

  .group-header.collapsed {
    opacity: 0;
    transition:
      background var(--duration-fast) ease,
      opacity var(--duration-instant) var(--ease-out);
  }

  .group-header:hover {
    background: var(--theme-card-bg);
  }

  .group-header:focus-visible {
    outline: 2px solid var(--theme-accent);
    outline-offset: 2px;
  }

  .chev {
    font-size: 0.7rem;
    color: var(--group-color);
    transition: transform var(--duration-emphasis) cubic-bezier(0.4, 0, 0.2, 1);
    flex-shrink: 0;
  }

  .chev.open {
    transform: rotate(90deg);
  }

  .group-icon {
    width: 18px;
    display: grid;
    place-items: center;
    flex-shrink: 0;
  }

  .group-icon :global(i) {
    color: var(--group-color);
    font-size: 0.85rem;
    filter: drop-shadow(0 1px 3px rgba(0, 0, 0, 0.3));
  }

  /* Holds its full width as the row narrows: the count chip after it goes first,
     so the name is not cut until the row's own edge reaches it. */
  .group-label {
    flex: 1 0 auto;
    text-align: left;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  }

  .group-count {
    font-size: 0.7rem;
    font-variant-numeric: tabular-nums;
    color: var(--theme-text-dim, rgba(255, 255, 255, 0.5));
    background: var(--theme-card-bg, rgba(255, 255, 255, 0.06));
    border-radius: 999px;
    padding: 1px 8px;
    flex-shrink: 0;
  }

  /* The indent eases away in the rail, where a row's icon sits under the module
     icon. The guide line is a pseudo-element, so it fades without moving a row. */
  .group-body {
    position: relative;
    padding-left: 13px;
    margin-left: 16px;
    transition:
      padding-left var(--duration-emphasis) var(--ease-out),
      margin-left var(--duration-emphasis) var(--ease-out);
  }

  .group-body::before {
    content: "";
    position: absolute;
    inset-block: 0;
    left: 0;
    width: 1px;
    background: color-mix(in srgb, var(--group-color, var(--theme-accent)) 18%, transparent);
    transition: opacity var(--duration-normal) var(--ease-out);
  }

  .group-body.collapsed {
    padding-left: 0;
    margin-left: 0;
  }

  .group-body.collapsed::before {
    opacity: 0;
    transition: opacity var(--duration-instant) var(--ease-out);
  }

  /* Celebrate animation - tabs revealed after tutorial */
  .section-item.celebrate {
    animation: sectionCelebrate 0.6s ease-out forwards;
    animation-delay: calc(0.15s + var(--item-index, 0) * var(--duration-instant));
  }

  @keyframes sectionCelebrate {
    0% {
      opacity: 0;
      transform: translateX(-20px) scale(0.9);
    }
    50% {
      transform: translateX(4px) scale(1.05);
    }
    100% {
      opacity: 1;
      transform: translateX(0) scale(1);
    }
  }

  .sections-list.celebrate {
    position: relative;
  }

  .sections-list.celebrate::before {
    content: "";
    position: absolute;
    inset: -8px;
    background: radial-gradient(
      ellipse at left center,
      color-mix(in srgb, var(--module-color, #a855f7) 20%, transparent),
      transparent 70%
    );
    border-radius: 16px;
    opacity: 0;
    animation: glowFadeIn 0.8s ease-out forwards;
    animation-delay: var(--duration-normal);
    pointer-events: none;
    z-index: -1;
  }

  @keyframes glowFadeIn {
    0% {
      opacity: 0;
    }
    50% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    *,
    .group-body::before {
      transition: none !important;
      animation: none !important;
    }
  }
</style>
